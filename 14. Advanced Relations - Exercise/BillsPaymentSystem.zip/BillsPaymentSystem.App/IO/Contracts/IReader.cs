﻿namespace BillsPaymentSystem.App.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
