﻿namespace BillsPaymentSystem.Data
{
    internal static class Config
    {
        internal const string ConnectionString = "Server=.;DataBase=BillsPaymentSystem;Integrated Security=True;";
    }
}