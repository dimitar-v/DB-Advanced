﻿namespace P01_HospitalDatabase.Data
{
    public class Config
    {
        public const string ConnectionString = "Server=.;DataBase=Hospital;Integrated Security=True;";
    }
}
