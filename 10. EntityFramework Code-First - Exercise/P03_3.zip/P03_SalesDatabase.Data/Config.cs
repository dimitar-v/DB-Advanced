﻿namespace P03_SalesDatabase.Data
{
    public class Config
    {
        public const string ConnectionString = "Server=.;DataBase=Sales;Integrated Security=True;";
    }
}
