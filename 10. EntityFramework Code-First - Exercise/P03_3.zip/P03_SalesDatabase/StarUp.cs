﻿namespace P03_SalesDatabase
{
    using System;

    public class StarUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
