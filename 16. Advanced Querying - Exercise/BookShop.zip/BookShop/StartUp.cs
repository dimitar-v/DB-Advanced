﻿namespace BookShop
{
    using Models.Enums;
    using Data;
    using Initializer;
    using System;
    using System.Linq;

    public class StartUp
    {
        public static void Main()
        {
            using (var db = new BookShopContext())
            {
                // 00.	Book Shop Database
                //DbInitializer.ResetDatabase(db);

                // 01.	Age Restriction
                //Write(GetBooksByAgeRestriction(db, "miNor"));

                // 02.	Golden Books
                Write(GetGoldenBooks(db));
            }
        }

        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            var ageRestriction = Enum.Parse<AgeRestriction>(command, true);

            var books = context.Books
                .Where(b => b.AgeRestriction == ageRestriction)
                .Select(b => b.Title)
                .OrderBy(t => t)
                .ToList();

            return string.Join(Environment.NewLine, books);
        }

        public static string GetGoldenBooks(BookShopContext context)
            => string.Join(Environment.NewLine, context.Books
            .Where(b => b.Copies < 5000 & b.EditionType == EditionType.Gold)
            .OrderBy(b => b.BookId)
            .Select(b => b.Title)
            .ToList());
            
        public static void Write(string text)
            => Console.WriteLine(text);
    }
}
