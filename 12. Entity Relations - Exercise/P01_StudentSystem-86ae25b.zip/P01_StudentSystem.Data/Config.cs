﻿namespace P01_StudentSystem.Data
{
    public static class Config
    {
        public const string ConnectionString = "Server=.;DataBase=StudentSystem;Integrated Security=True;";
    }
}