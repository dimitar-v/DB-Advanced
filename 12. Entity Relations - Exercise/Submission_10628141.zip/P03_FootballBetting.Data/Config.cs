﻿namespace P03_FootballBetting.Data
{
    public static class Config
    {
        public const string ConnectionString = "Server=.;DataBase=FootballBookmakerSystem;Integrated Security=True;";
    }
}