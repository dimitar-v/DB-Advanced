﻿namespace P03_FootballBetting.Data.Models
{
    public enum PredictionType
    {
        Draw = 0,
        HomeTeam = 1,
        AwayTeam = 2
    }
}